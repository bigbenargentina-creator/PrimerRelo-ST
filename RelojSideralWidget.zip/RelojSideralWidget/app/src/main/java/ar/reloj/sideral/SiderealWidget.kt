package ar.reloj.sideral

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

/**
 * Widget de 3 líneas:
 *   HL  hora local (la del teléfono)
 *   ST  hora sideral local
 *   EC  signo y grado (0h = 0° Aries; 18h = 0° Capricornio)
 */
class SiderealWidget : AppWidgetProvider() {

    companion object {
        // ---- Lugar: Mar del Plata. Longitud en grados, Este positivo / Oeste negativo. ----
        const val LONGITUD = -57.5575

        private const val ACTION_TICK = "ar.reloj.sideral.TICK"

        private val SIGNOS = arrayOf(
            "Ari", "Tau", "Gem", "Can", "Leo", "Vir",
            "Lib", "Esc", "Sag", "Cap", "Acu", "Pis"
        )

        /** Tiempo sideral medio en Greenwich, en grados (0..360). */
        fun gmstGrados(ms: Long): Double {
            val jd = ms / 86400000.0 + 2440587.5
            val d = jd - 2451545.0
            val t = d / 36525.0
            var g = 280.46061837 + 360.98564736629 * d + 0.000387933 * t * t - t * t * t / 38710000.0
            g %= 360.0
            if (g < 0) g += 360.0
            return g
        }

        fun actualizar(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, SiderealWidget::class.java))
            if (ids.isEmpty()) return

            val ahora = System.currentTimeMillis()

            // Hora local
            val cal = Calendar.getInstance().apply { timeInMillis = ahora }
            val hl = "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))

            // Hora sideral local
            var lst = (gmstGrados(ahora) + LONGITUD) % 360.0
            if (lst < 0) lst += 360.0
            val horas = lst / 15.0
            val h = horas.toInt()
            val m = ((horas - h) * 60.0).toInt()
            val st = "%02d:%02d".format(h, m)

            // Signo y grado
            val signo = SIGNOS[(lst / 30.0).toInt() % 12]
            val grado = (lst % 30.0).toInt()
            val ec = "$signo %02d°".format(grado)

            val views = RemoteViews(context.packageName, R.layout.widget)
            views.setTextViewText(R.id.hl, hl)
            views.setTextViewText(R.id.st, st)
            views.setTextViewText(R.id.ec, ec)
            mgr.updateAppWidget(ids, views)
        }

        private fun pendiente(context: Context): PendingIntent {
            val intent = Intent(context, SiderealWidget::class.java).setAction(ACTION_TICK)
            return PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Programa la próxima actualización al comienzo del minuto siguiente. */
        private fun programar(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val proximo = (System.currentTimeMillis() / 60000L + 1) * 60000L + 300L
            alarm.setAndAllowWhileIdle(AlarmManager.RTC, proximo, pendiente(context))
        }

        private fun cancelar(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.cancel(pendiente(context))
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        programar(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelar(context)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        actualizar(context)
        programar(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_TIME_CHANGED -> {
                actualizar(context)
                programar(context)
            }
        }
    }
}
